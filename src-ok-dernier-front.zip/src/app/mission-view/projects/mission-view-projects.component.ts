import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mission-view-projects',
  templateUrl: './mission-view-projects.component.html',
  styleUrls: ['./../mission-view.component.scss']
})
export class MissionViewProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
