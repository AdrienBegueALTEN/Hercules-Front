export enum HttpStatus {
    CREATED = 201,
    ACCEPTED = 202,
    CONFLICT = 409
}
