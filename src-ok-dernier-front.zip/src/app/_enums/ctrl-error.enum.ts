export enum CtrlError {
    PATTERN = 'pattern',
    REQUIRED = 'required'
}
